var SITE_BASE_URL = window.location.protocol + "//www.zespoke.com"

var URLS = {

	'BG_IMAGE': SITE_BASE_URL + '/wp-content/themes/zespoke/imgs/table-background.jpg'

}
