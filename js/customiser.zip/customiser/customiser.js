
	var aspect = 1.33334;

	var view_angle = 45;
	var near = 0.1;
	var far = 1000;
	var focus = new THREE.Vector3(-10,300,0);
	var position = new THREE.Vector3(0,0,-200);
	var changed = true;
	var composer;
	var bgComposer;
	var fxaaShader;
	var resized = false;
	var productID = 0;

	var getWidth = function() {

		return jQuery('#customiser').width();

	}

	var getHeight = function() {

		return getWidth() / aspect;

	}

	var resizeCustomiser = function() {

		width = getWidth();
		height = getHeight();
		resized = true;
		renderer.setSize(width, height);
		fxaaShader.uniforms['resolution'].value = new THREE.Vector2(1/width, 1/height);

	}

	jQuery(window).on('resize', resizeCustomiser);

	var texture = THREE.ImageUtils.loadTexture(URLS.BG_IMAGE);
	var backgroundMesh = new THREE.Mesh(
		new THREE.BoxGeometry(2,2,100),
		new THREE.MeshBasicMaterial({
			map: texture

		}));


	backgroundMesh.doubleSided = true;
	backgroundMesh.material.depthTest = false;
	backgroundMesh.material.depthWrite = false;
	backgroundMesh.position.set(0, 0, -50)

	//Create the Background Scene.

	var backgroundScene = new THREE.Scene();
	var backgroundCamera = new THREE.OrthographicCamera(-1,1,1,-1,1, 1000);

	camera = new THREE.PerspectiveCamera(view_angle, aspect, near, far);
	backgroundCamera.position.set(0,0,100);
	backgroundCamera.lookAt(new THREE.Vector3(0,0,0));
	backgroundScene.add(backgroundCamera);
	backgroundScene.add(backgroundMesh);

	foregroundScene = new THREE.Scene();
	foregroundCamera = new THREE.PerspectiveCamera();

	backgroundCamera.position.set(0,0,100);
	backgroundCamera.lookAt(new THREE.Vector3(0,0,0));

	foregroundScene.add(foregroundCamera);

	var view_angle = 45;
	var near = 0.1;
	var far = 1000;
	var focus = new THREE.Vector3(-10,300,0);
	var position = new THREE.Vector3(0,0,-200);

	var renderer;
	var camera;
	var scene;
	var manager = new THREE.LoadingManager();

	var textures = {};
	var textureMap = {};

	var spinner;

	var curTable;

	var floor;

	var objects = [];
	var options = [];

	var curTextures = {};
	var LoadingObject = function() {

		this.total = 0;
		this.loading = 0;
	
		this.load = function() {
	
			this.total++;
			this.loading++;
	
		}
	
		this.unload = function() {
	
			if (this.loading > 0) {
		
				this.loading--;
			
			}
		
		}
	
		this.loaded = function() {
	
			return this.loading <= 0;
	
		}
	
		this.getTotal = function() {
	
			return this.total;
	
		}

	}



	var Loading = new LoadingObject();

	var onProgress = function(xhr) {

		if (xhr.lengthComputable) {

			var percentComplete = xhr.loaded / xhr.total * 100;

		}

	};

	var onError = function(xhr) {

		//console.log('Error loading file.');

	}

	var table;
	var geometry;
	var material;

	manager.onProgress = function(item, loaded, total) {

		//console.log(item, loaded, total);

	}	

	var initLighting = function() {
		
		// ***************************************
		// GENERAL POSITIONAL COMMENTS
		//(x, y, z) (
		// for x positive is left
		// for y positive is up
		// for z positive is away from the camera
		// ***************************************

		var ambiantLight = new THREE.AmbientLight(/**0x2a2a2a**/ 0x3a3a3a);

		var spotlight3 = new THREE.PointLight(0xFFFFFF, 1.3);
		spotlight3.position.set(-230, 60, -84);
		
		var light4 = new THREE.SpotLight(0xFFFFFF, 4.0, 175, Math.PI/2);
		light4.position.set(20, 195, 0);
		spotlight3.shadowMapWidth = 2048;
		spotlight3.shadowMapHeight = 2048;
		
		var point = new THREE.PointLight(0xffffff, 0.8);
		point.position.set(100, 92, 43);
				
		scene.add(point);
		//back left highlight
		scene.add(spotlight3)
		//front right
		scene.add(light4);
		//top right
		scene.add(ambiantLight);
		//ambient

	}

	var addFloor = function() {

		var geometry = new THREE.BoxGeometry(1,1,1);
		var material = new THREE.MeshPhongMaterial({
			ambient: 0xFFFFFF,
			color: 0xFF,
			shininess: 20,
			specular: 0x888888,
		});

		var cube = new THREE.Mesh(geometry, material); 

		cube.traverse(function(object) {

			object.recieveShadow = true;
			object.castShadow = false;

		});
	
		cube.position.y = 0.2;
		cube.position.x = 0.2;
		cube.position.z = 0;
		floor = cube;

		cube.receiveShadow = true;

	}

	var animate = function() {

		requestAnimationFrame(animate);
		renderer.clear();

		if (false && !Loading.loaded()) {

			if (jQuery('.customiser .spinner-loader').length <= 0) {
			
				jQuery('.customiser').append("<div class='spinner-loader'></div><div class='spinner-loader-text'>Loading..</div>");
		
			}	
		

		} else {

			if (jQuery('.customiser .spinner-loader').length > 0) {

				jQuery('.spinner-loader, .spinner-loader-text').remove();

			}
		
			for(var i = 0; i < objects.length; i++) {

				objects[i].manipulation();

			}

			renderer.autoClear = false;
			renderer.clear();
			
			composer.render();			
		
		}

	}

	var initRenderer = function() {
		
				var params = { minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, format: THREE.RGBAFormat, stencilBuffer: false };
				renderer = new THREE.WebGLRenderer({preserveDrawingBuffer: true, antialias: false, alpha: true, precision: "highp"});
				
				if (renderer.getContext()) {

					var width = getWidth();
					var height = getHeight();

					renderer.shadowMapEnabled = true;
					renderer.shadowMapSoft = true;
					renderer.shadowMapType = THREE.PCFSoftShadowMap;
					renderer.shadowCameraNear = 3;
					renderer.shadowCameraFar = camera.far;
					renderer.shadowCameraFov = 50;
					renderer.shadowMabBias = 0.0039;
					renderer.shadowMapDarkness = 0.5;
					renderer.setClearColor(0x000000, 0);
					renderer.setSize(width, height);
					renderer.autoClearColor = false;
					
					drawBuffer = new THREE.WebGLRenderTarget(width * 4, height * 4);
					renderer.domElement.id = "customiserCanvas";
					
					var renderTarget = new THREE.WebGLRenderTarget(width, height, params);
					composer = new THREE.EffectComposer(renderer, renderTarget);
					
					var bgRenderPass = new THREE.RenderPass(backgroundScene, backgroundCamera);
					composer.addPass(bgRenderPass);

					var renderPass = new THREE.RenderPass(scene, camera, null, new THREE.Color(0xFFFFFF), 1);
					renderPass.renderToScreen = true;
					composer.addPass(renderPass);
	
					var dotScreenEffect = new THREE.ShaderPass( THREE.DotScreenShader );
                        		dotScreenEffect.uniforms[ 'scale' ].value = 4;
                        		
					fxaaShader = new THREE.ShaderPass(THREE.FXAAShader);
					fxaaShader.uniforms['resolution'].value = new THREE.Vector2(1/width, 1/height);					
					

					dotScreenEffect.renderToScreen = true;
					fxaaShader.renderToScreen = true;
					composer.addPass(fxaaShader);					

					var dlink = "<a id='customiserImage' download>Picture</a>";
					
					jQuery('div.customiser').append(renderer.domElement);

				} else {

					jQuery('div.main-image').removeClass('hidden');
					jQuery('div#customiser').addClass('hidden');

				}

	}

	var initCamera = function() {

		camera = new THREE.PerspectiveCamera(view_angle, aspect, near, far);

		camera.position.set(50,75,-100);
		
		//camera.position.set(87, 92, 43);
		camera.lookAt(focus);

	}

	var setCameraLookAt = function(table) {

		var boundingBox = new THREE.Box3().setFromObject(table);
		var floorBox = new THREE.Box3().setFromObject(floor);
	
		focus.y = 10/**(boundingBox.max.y / 2) + floorBox.max.y;**/
		focus.z = (boundingBox.max.z - boundingBox.min.z)/2
		camera.lookAt(focus);

	}

	var initScene = function() {

		scene = new THREE.Scene();

	}

	var getProductID = function() {

		var product = jQuery("input[name=product]").val();
		return product;

	}

	var getObjectFile = function() {

		var objfile = jQuery("input[name=object_file]").val();
		return objfile;

	}

	var getMaterialFile = function() {

		var matfile = jQuery("input[name=materials_file]").val();
		return matfile;

	}

	var getScale = function() {

		var scale = jQuery("input[name=scale]").val();
		return scale;

	}

	var getRotation = function() {

		var rotation = jQuery("input[name=rotation]").val();

	}

	var init = function(product) {

		try {

			if (!Modernizr.webgl) {

				console.log("No WebGL Support");
				throw "WebGL Not Supported";

			}


			console.log("Texture Loader");
			console.log(THREE.TextureLoader);
			THREE.TextureLoader.prototype.crossOrigin = '';

			var product = getProductID();
			console.log("Product ID: " + product);

			var objfile = getObjectFile();
			console.log(objfile);
			var matfile = getMaterialFile();
			console.log(matfile);
			var scale = jQuery("input[name=scale]").val();
			var rotation = jQuery("input[name=rotation]").val();
			console.log("X Translation");
			var xtrans = jQuery("input[name=translation_x]").val();
			console.log(xtrans);
			var ytrans = jQuery("input[name=translation_y]").val();			

			initCamera();
			initScene();
			initRenderer();
			initLighting();

			addFloor();
			
			setTable(product, scale, rotation, xtrans, ytrans);

			animate();
		
		} catch (err) {
		
			console.log("An Error occurred");
			console.log(err.stack);
			jQuery('.main-image').removeClass('hidden');
			jQuery('div#customiser').remove();
					
		}

	}

	var getAJAXObject = function() {

		var xmlhttp;

		if (window.XMLHttpRequest) {

			xmlhttp = new XMLHttpRequest();

		} else {

			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

		}

		return xmlhttp;

	}

	var jsonHttpRequest = function(url, method) {

		var xmlhttp = getAJAXObject();

		xmlhttp.open("GET", url, true);
		xmlhttp.timeout = 4000;
		xmlhttp.send();

		xmlhttp.onreadystatechange = function() {

			if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

				console.log(url);
				var response = JSON.parse(xmlhttp.responseText)
				method(response);
			

			}

		}
	

	}

	var addInterface = function() {

		jQuery("body").append('<button id="export" value="Export">Export</button>')

	}
	
	jQuery(document).ready(function() {

		/** Find the Default Textures **/
		var getDefaultTextures = function() {

			var defaultTextures = jQuery('.ac-row.texture article input[type=radio]').filter(':checked');

			defaultTextures.each(function(i) {

				var $input = jQuery(this);
				var side = $input.closest('.ac-row').data('side');
				var textureId = $input.data('texture');

				jQuery.ajax({

                                	url: '/wp-admin/admin-ajax.php',
                               		type: 'GET',
                                	dataType: 'json',
                                	data: {

                                        	'action': 'customiser_texture_request',
                                        	'texture': textureId

                                	},
                                	success: function(data) {

                                        	var loader = new THREE.TextureLoader();

                                        	loader.load(data.texture, function(theTexture) {

							var sides = side.split(',');

                                                	data.texture = theTexture;

							sides.forEach(function(side) {

								data.Ref = side;
								table.useTexture(data);

							});
                                                	//data.Ref = side;
                                                	//table.useTexture(data);

                                        	});
                                        	data.Ref = side;
                                	},
                                	error: function(err) {

                                        	console.log(err);

                                	}

                        	});

			});

		}

		//setTimeout(getDefaultTextures, 4000);

		jQuery(".ac-row.option article input[type=radio]").on('click', function(e) {

			$input = jQuery(this);
			side = $input.closest('.ac-row').data('side');
			val = $input.val();

			if (val == 'Yes') {

				table.showTexture(side);

			} else if (val == 'No') {

				table.hideTexture(side);

			}

		});

		jQuery(".ac-row.texture article input[type=radio]").on('click', function(e) {

			$input = jQuery(this);
			side = $input.closest('.ac-row').data('side');

			textureId = $input.data('texture');	

			console.log(textureId);
			
			jQuery.ajax({

				url: '/wp-admin/admin-ajax.php',
				type: 'GET',
				dataType: 'json',
				data: {

					'action': 'customiser_texture_request',
					'texture': textureId

				},
				success: function(data) {
					
					console.log(data);

					THREE.TextureLoader.prototype.crossOrigin = '';
					var loader = new THREE.TextureLoader();
					loader.crossOrigin = '';

					console.log("Loading");

					loader.load(data.texture, function(theTexture) {
						
						console.log(data.texture);
						console.log("Loaded");
						var sides = side.split(',');
						console.log(sides);

                                                data.texture = theTexture;

						sides.forEach(function(side) {

							console.log(side);
						
							data.Ref = side;
							table.useTexture(data);

							console.log("Using Texture");

						});


                                        });
	
					data.Ref = side;	
				},
				error: function(err) {

					console.log(err);
				
				}

			});

		});	
		
	});

	var setTable = function getModel(tableID, scale, rot, x, y) {
		
		var reflection = false;
		var host = SITE_BASE_URL;/**window.location.host + window.location.pathname;**/
		var url = "/wp-admin/admin-ajax.php?action=customiser_get_table_request&product=" + tableID; 

		console.log(url);
		
		jsonHttpRequest(url, function(json) {
		
			var baseURL = SITE_BASE_URL + "/assets/files/";
			console.log("The Object File URL:");
			console.log(json.Object_File);
			table = new Table(json.Object_File, json.Material_File, [], reflection, tableID, scale, rot, x, y);
			table.init(options);
			url = host + "index.php?";
			
		});

	}
